﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnclose.Click += new EventHandler(btnclose_Click);
        }

        private void btnwelcome_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome " + txtname.Text + " !!!");
        }

        private void btnwelcome_MouseLeave(object sender, EventArgs e)
        {
            //sender is source of event ie: btnwelcome button.
            Button b = sender as Button;
            b.BackColor = SystemColors.Control;
            b.ForeColor = Color.Black;
        }

        private void btnwelcome_MouseEnter(object sender, EventArgs e)
        {
            //sender is source of event ie: btnwelcome button.
            Button b = sender as Button;
            b.BackColor = Color.Yellow;
            b.ForeColor = Color.OrangeRed;
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {


        }

        private void mouseEnter(object sender, EventArgs e)
        {
            TextBox b = sender as TextBox;
            b.BackColor = Color.Green;
            b.ForeColor = Color.OrangeRed;

        }

        private void mouseLeave(object sender, EventArgs e)
        {
            TextBox b = sender as TextBox;
            b.BackColor = Color.White;
            b.ForeColor = Color.White;

        }
    }
}
