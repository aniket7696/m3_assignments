﻿namespace Lab_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtname = new System.Windows.Forms.Label();
            this.txtbirthdate = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.imgcal = new System.Windows.Forms.PictureBox();
            this.btnregistration = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).BeginInit();
            this.SuspendLayout();
            // 
            // txtname
            // 
            this.txtname.AutoSize = true;
            this.txtname.Location = new System.Drawing.Point(337, 119);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(38, 13);
            this.txtname.TabIndex = 0;
            this.txtname.Text = "Name:";
            this.txtname.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtbirthdate
            // 
            this.txtbirthdate.AutoSize = true;
            this.txtbirthdate.Location = new System.Drawing.Point(337, 175);
            this.txtbirthdate.Name = "txtbirthdate";
            this.txtbirthdate.Size = new System.Drawing.Size(57, 13);
            this.txtbirthdate.TabIndex = 0;
            this.txtbirthdate.Text = "Birth Date:";
            this.txtbirthdate.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(437, 119);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // imgcal
            // 
            this.imgcal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.imgcal.Image = ((System.Drawing.Image)(resources.GetObject("imgcal.Image")));
            this.imgcal.InitialImage = ((System.Drawing.Image)(resources.GetObject("imgcal.InitialImage")));
            this.imgcal.Location = new System.Drawing.Point(560, 172);
            this.imgcal.Margin = new System.Windows.Forms.Padding(0);
            this.imgcal.Name = "imgcal";
            this.imgcal.Size = new System.Drawing.Size(19, 20);
            this.imgcal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgcal.TabIndex = 2;
            this.imgcal.TabStop = false;
            this.imgcal.Click += new System.EventHandler(this.onClick);
            // 
            // btnregistration
            // 
            this.btnregistration.Location = new System.Drawing.Point(437, 234);
            this.btnregistration.Name = "btnregistration";
            this.btnregistration.Size = new System.Drawing.Size(75, 23);
            this.btnregistration.TabIndex = 3;
            this.btnregistration.Text = "Register";
            this.btnregistration.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(437, 172);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.btnregistration);
            this.Controls.Add(this.imgcal);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtbirthdate);
            this.Controls.Add(this.txtname);
            this.Name = "Form1";
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtname;
        private System.Windows.Forms.Label txtbirthdate;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox imgcal;
        private System.Windows.Forms.Button btnregistration;
        private System.Windows.Forms.TextBox textBox2;
    }
}

