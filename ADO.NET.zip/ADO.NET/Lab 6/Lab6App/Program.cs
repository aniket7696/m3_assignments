﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6App
{
    class Program
    {
 
        static void Main(string[] args)
        {
            List<Employee> employee = new List<Employee>
            {
                new Employee { EmployeeID = 1001, FirstName = "Malcolm", LastName = "Daruwalla", Title ="Manager", DOB = Convert.ToDateTime("11/16/1984"), DOJ = Convert.ToDateTime("08/06/2011"),City = "Mumbai" },
                new Employee { EmployeeID = 1002, FirstName = "Asdin", LastName = "Dhalla", Title ="AsstManager", DOB = Convert.ToDateTime("08/20/1984"), DOJ = Convert.ToDateTime("7/7/2012 "),City = "Mumbai" },
                new Employee { EmployeeID = 1003, FirstName = "Madhavi", LastName = "Oza", Title ="Consultant", DOB = Convert.ToDateTime("11/14/1987"), DOJ = Convert.ToDateTime("12/4/2015"),City = "Pune" },
                new Employee { EmployeeID = 1004, FirstName = "Saba", LastName = "Shaikh", Title ="SE", DOB = Convert.ToDateTime("2/2/2016"), DOJ = Convert.ToDateTime("2/2/2016"),City = "Pune" },
                new Employee { EmployeeID = 1005, FirstName = "Nazia", LastName = "Shaikh", Title ="SE", DOB = Convert.ToDateTime("2/2/2016"), DOJ = Convert.ToDateTime("2/2/2016"),City = "Mumbai" },
                new Employee { EmployeeID = 1006, FirstName = "Amit", LastName = "Pathak", Title ="Consultant", DOB = Convert.ToDateTime("7/11/1989"), DOJ = Convert.ToDateTime("8/8/2014"),City = "Chennai" },
                new Employee { EmployeeID = 1007, FirstName = "Vijay", LastName = "Natrajan", Title ="Consultant", DOB = Convert.ToDateTime("2/12/1989"), DOJ = Convert.ToDateTime("1/6/2015"),City = "Mumbai" },
                new Employee { EmployeeID = 1008, FirstName = "Rahul", LastName = "Dubey", Title ="Associate", DOB = Convert.ToDateTime("11/11/1993"), DOJ = Convert.ToDateTime("6/11/2014"),City = "Chennai" },
                new Employee { EmployeeID = 1009, FirstName = "Suresh", LastName = "Mistry", Title ="Associate", DOB = Convert.ToDateTime("12/8/1992"), DOJ = Convert.ToDateTime("3/12/2014"),City = "Chennai" },
                new Employee { EmployeeID = 1010, FirstName = "Sumit", LastName = "Shah", Title ="Manager", DOB = Convert.ToDateTime("12/4/1991"), DOJ = Convert.ToDateTime("2/1/2016"),City = "Pune" }
            };

            ////Q3.1
            //var res = from e in employee
            //          select e;
            //foreach (var i in res)
            //{
            //    Console.WriteLine("EmployeeID: {0}, FirstName: {1}, LastName: {2}, Title: {3}, DOB: {4}, DOJ: {5}, City: {6}", i.EmployeeID, i.FirstName, i.LastName, i.Title, i.DOB, i.DOJ, i.City);
            //}

            ////Q3.2
            //var res = employee.Where(e => e.City != "Mumbai");
            //foreach (var i in res)
            //{
            //    Console.WriteLine("EmployeeID: {0}, FirstName: {1}, LastName: {2}, Title: {3}, DOB: {4}, DOJ: {5}, City: {6}", i.EmployeeID, i.FirstName, i.LastName, i.Title, i.DOB, i.DOJ, i.City);
            //}

            ////Q3.3
            //var res = employee.Where(e => e.Title == "AsstManager");
            //foreach (var i in res)
            //{
            //    Console.WriteLine("EmployeeID: {0}, FirstName: {1}, LastName: {2}, Title: {3}, DOB: {4}, DOJ: {5}, City: {6}", i.EmployeeID, i.FirstName, i.LastName, i.Title, i.DOB, i.DOJ, i.City);
            //}

            ////Q3.4
            //var res = employee.Where(e => e.LastName.StartsWith("S"));
            //foreach (var i in res)
            //{
            //    Console.WriteLine("EmployeeID: {0}, FirstName: {1}, LastName: {2}, Title: {3}, DOB: {4}, DOJ: {5}, City: {6}", i.EmployeeID, i.FirstName, i.LastName, i.Title, i.DOB, i.DOJ, i.City);
            //}

            ////Q3.5
            //var res = employee.Where(e => e.DOJ.Year < 2015 );
            //foreach (var i in res)
            //{
            //    Console.WriteLine("EmployeeID: {0}, FirstName: {1}, LastName: {2}, Title: {3}, DOB: {4}, DOJ: {5}, City: {6}", i.EmployeeID, i.FirstName, i.LastName, i.Title, i.DOB, i.DOJ, i.City);
            //}

            ////Q3.6
            //var res = employee.Where(e => e.DOB.Year > 1991);
            //foreach (var i in res)
            //{
            //    Console.WriteLine("EmployeeID: {0}, FirstName: {1}, LastName: {2}, Title: {3}, DOB: {4}, DOJ: {5}, City: {6}", i.EmployeeID, i.FirstName, i.LastName, i.Title, i.DOB, i.DOJ, i.City);
            //}

            ////Q3.7
            //var res = employee.Where(e => e.Title == "Consultant" | e.Title == "Associate");
            //foreach (var i in res)
            //{
            //    Console.WriteLine("EmployeeID: {0}, FirstName: {1}, LastName: {2}, Title: {3}, DOB: {4}, DOJ: {5}, City: {6}", i.EmployeeID, i.FirstName, i.LastName, i.Title, i.DOB, i.DOJ, i.City);
            //}

            ////Q3.8
            //int res = employee.Count();
            //Console.WriteLine(res);

            ////Q3.9
            //var res = employee.Where(e => e.City == "Chennai").Count();
            //Console.WriteLine(res);

            ////Q3.10
            //var res = employee.Where(s => s.EmployeeID == employee.Max(e => e.EmployeeID));
            //foreach (var i in res)
            //{
            //    Console.WriteLine("Highest Employee ID: {0}", i.EmployeeID);
            //}

            ////Q3.11
            //var res = employee.Where(e => e.DOJ.Year > 2015).Count();
            //Console.WriteLine(res);

            ////Q3.12
            //var res = employee.Where(e => e.Title != "Associate").Count();
            //Console.WriteLine(res);

            ////Q3.13
            //var res = employee.Select(e => e.City).Distinct();
            //int ans = res.Count();
            //Console.WriteLine(ans);

            ////Q3.14
            //var res = employee.GroupBy(x => x.City).Count();
            //var res1 = employee.GroupBy(x => x.Title).Count();
            //Console.WriteLine("Number of employee based on city: {0}\nNumber of employee based on title: {1}", res, res1);
            
            //var res = employee..Distinct();
            //int ans = res.Count();
            //Console.WriteLine(ans);

            ////Q3.15
            //var res = employee.Where(s => s.DOB.Year == employee.Min(e => e.DOB.Year)).Count();
            //Console.WriteLine(res);
        }
    }
}
