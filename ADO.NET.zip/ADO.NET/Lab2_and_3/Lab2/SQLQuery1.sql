﻿create table aish164277.applicationusers
(
userid varchar(10) primary key,
username varchar(30) not null,
city varchar(30) not null,
password varchar(30) check(len(password) >5)
)

insert into aish164277.applicationusers values ('102','raksha','pune',1234567);
select * from aish164277.applicationusers;