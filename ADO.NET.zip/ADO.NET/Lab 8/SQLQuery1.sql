﻿select * from Student_master


--To check if the data is added or not
select top 1000 [Stud_Code], 
				[Stud_Name], 
				[Dept_Code],
				[Stud_Dob],
				[Address] 
from dbo.Student_master

--To check if the data is updated or not and deleted or not
select top 1000 [Stud_Code], 
				[Stud_Name], 
				[Dept_Code],
				[Stud_Dob],
				[Address] 
from dbo.Student_master
where [Stud_Code] = 1020

create table Shariq.Employee
(
	[ID] int primary key not null,
	[Name] varchar(20),
	[DOB] date,
	[DOJ] date,
	[Designation] varchar (20),
	[Salary] int
);
