﻿drop table employee

create table employee
( empno int primary key,
empname varchar(50) not null,
empsal numeric(10,2) check(empsal >= 25000) ,
emptype varchar(1) check(emptype in('C','P'))
)
go
create proc GetEmployeeById
@eno int
as
select * from employee where empno = @eno
go