﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductDb dbContext = new ProductDb();

            Product7 p1 = new Product7()
            {
                ProdId = 101,
                Name = "Beyblade",
                Category = "Toy",
                Price = 250
            };

            Product7 p2 = new Product7()
            {
                ProdId = 101,
                Name = "Yoyo",
                Category = "Toy",
                Price = 150
            };

            dbContext.Products.Add(p1);
            dbContext.Products.Add(p2);
            dbContext.SaveChanges();

            Console.WriteLine("Product Details are added successfully!");

        }
    }
}
