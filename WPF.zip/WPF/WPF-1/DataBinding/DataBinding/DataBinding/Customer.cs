﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;

namespace DataBinding
{
    public class Customer : DependencyObject
    {
        protected static DependencyProperty CustIDProperty = DependencyProperty.Register("CustID", typeof(string), typeof(Customer));
        protected static DependencyProperty CustNameProperty = DependencyProperty.Register("CustName", typeof(string), typeof(Customer));
        protected static DependencyProperty CreditLimitProperty = DependencyProperty.Register("CreditLimit", typeof(double), typeof(Customer));
        protected static DependencyProperty PremiumProperty = DependencyProperty.Register("Premium", typeof(bool), typeof(Customer));
        public string CustID
        {
            get { return GetValue(Customer.CustIDProperty).ToString(); }
            set
            {
                SetValue(Customer.CustIDProperty, value);
            }
        }
        public string CustName
        {
            get { return GetValue(Customer.CustNameProperty).ToString(); }
            set
            {
                SetValue(Customer.CustNameProperty, value);
            }
        }
        public double CreditLimit
        {
            get { return (double)GetValue(Customer.CreditLimitProperty); }
            set
            {
                SetValue(Customer.CreditLimitProperty, value);
            }
        }
        public bool Premium
        {
            get { return (bool)GetValue(Customer.PremiumProperty); }
            set
            {
                SetValue(Customer.PremiumProperty, value);
            }
        }

        public bool IsSaveEnabled { get; private set; }

        public void GetData()
        {
            CustomerService cs = new CustomerService();
            cs.GetData(this.CustID, this);
            this.IsSaveEnabled = true;
        }
        public void SaveChanges()
        {
            CustomerService cs = new CustomerService();
            cs.SaveChanges(this);
            this.IsSaveEnabled = false;
        }
    }
}
