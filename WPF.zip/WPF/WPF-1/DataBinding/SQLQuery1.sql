﻿create table aish164277.cust
(
custid varchar(10) primary key,
custname varchar(50),
credlimit numeric(10,2),
IsPremium bit
)
insert into aish164277.cust values('an','anand',10000,1)
insert into aish164277.cust values('mil','milind',15000,1)
insert into aish164277.cust values('sac','sachin',25000,0)