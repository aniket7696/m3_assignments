﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAB1_3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //private void OnChangeResource(object sender, RoutedEventArgs e)
        //{
        //    MyContainer.Resources.Clear();
        //    LinearGradientBrush brush = new LinearGradientBrush();
        //    brush.StartPoint = new Point(0.5, 0);
        //    brush.EndPoint = new Point(0.5, 1);
        //    GradientStopCollection stops = new GradientStopCollection();
        //    stops.Add(new GradientStop(Colors.White, 0.0));
        //    stops.Add(new GradientStop(Colors.Yellow, 0.14));
        //    stops.Add(new GradientStop(Colors.YellowGreen, 0.7));
        //    brush.GradientStops = stops;
        //    MyContainer.Resources.Add("MyGradientBrush", brush);
        //}
    }
}
